# common

`MOTD`, `make`, `Lynis` profile.
