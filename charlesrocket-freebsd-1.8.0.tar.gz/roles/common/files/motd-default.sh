#!/bin/sh
figlet "$(hostname)" | lolcat -f && echo
