# git_ports

Deploy FreeBSD ports source with git
