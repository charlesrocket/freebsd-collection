# laptop

Tasks for laptop targets
